import { Injectable, NotFoundException, Inject } from '@nestjs/common';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ProductsService {
  constructor(
    private prisma: PrismaService,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) {}

  async findAll(filters?: {
    tenantId?: string;
    categoryId?: string;
    categorySlug?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    tags?: string[];
    isFeatured?: boolean;
    page?: number;
    limit?: number;
    includeInactive?: boolean; // For admin use
  }) {
    const where: any = {
      deletedAt: null,
    };

    if (filters?.tenantId) {
      where.tenantId = filters.tenantId;
    }

    // Only filter by isActive if not explicitly including inactive products
    if (!filters?.includeInactive) {
      where.isActive = true;
    }

    // Handle category filtering by ID or slug
    if (filters?.categoryId) {
      where.categoryId = filters.categoryId;
    } else if (filters?.categorySlug) {
      // Find category by slug first
      console.log('[ProductsService] Looking up category by slug:', filters.categorySlug);
      const category = await this.prisma.category.findFirst({
        where: { slug: filters.categorySlug, ...(filters?.tenantId && { tenantId: filters.tenantId }) },
      });
      if (category) {
        console.log('[ProductsService] Found category:', category.name, 'ID:', category.id);
        where.categoryId = category.id;
      } else {
        console.log('[ProductsService] ⚠️  Category not found for slug:', filters.categorySlug);
      }
    }

    if (filters?.search) {
      where.OR = [
        { name: { contains: filters.search, mode: 'insensitive' } },
        { description: { contains: filters.search, mode: 'insensitive' } },
      ];
    }

    if (filters?.minPrice || filters?.maxPrice) {
      where.price = {};
      if (filters.minPrice) where.price.gte = filters.minPrice;
      if (filters.maxPrice) where.price.lte = filters.maxPrice;
    }

    if (filters?.tags && filters.tags.length > 0) {
      where.tags = { hasSome: filters.tags };
    }

    if (filters?.isFeatured !== undefined) {
      where.isFeatured = filters.isFeatured;
    }

    const page = filters?.page || 1;
    const limit = filters?.limit || 20;
    const skip = (page - 1) * limit;

    // Create cache key based on filters
    const cacheKey = `products:${JSON.stringify({ where, page, limit })}`;
    
    // Try to get from cache (only for active products, not admin queries)
    if (!filters?.includeInactive) {
      try {
        const cached = await this.cacheManager.get(cacheKey);
        if (cached) {
          console.log('📦 Cache HIT:', cacheKey.substring(0, 50) + '...');
          return cached;
        }
      } catch (error) {
        console.warn('⚠️  Cache get error:', error.message);
      }
    }

    // Debug logging
    console.log('[ProductsService] Query where:', JSON.stringify(where, null, 2));
    console.log('[ProductsService] Pagination:', { page, limit, skip });
    console.log('💾 Cache MISS:', cacheKey.substring(0, 50) + '...');

    const [products, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        include: {
          category: true,
          images: { orderBy: { sortOrder: 'asc' } },
          inventory: true,
          variants: {
            where: { isActive: true },
            orderBy: { createdAt: 'asc' },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.product.count({ where }),
    ]);

    console.log('[ProductsService] Found products:', products.length, 'Total:', total);

    const result = {
      data: products,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
      // Keep meta for backward compatibility
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };

    // Store in cache for 5 minutes (only for active products)
    if (!filters?.includeInactive) {
      try {
        await this.cacheManager.set(cacheKey, result, 300000); // 5 minutes in ms
      } catch (error) {
        console.warn('⚠️  Cache set error:', error.message);
      }
    }

    return result;
  }

  async findOne(id: string, tenantId?: string) {
    const cacheKey = `product:${tenantId || 'global'}:${id}`;
    
    // Try to get from cache
    try {
      const cached = await this.cacheManager.get(cacheKey);
      if (cached) {
        console.log('📦 Cache HIT:', cacheKey);
        return cached;
      }
    } catch (error) {
      console.warn('⚠️  Cache get error:', error.message);
    }

    console.log('💾 Cache MISS:', cacheKey);

    const product = await this.prisma.product.findUnique({
      where: { id },
      include: {
        category: true,
        images: { orderBy: { sortOrder: 'asc' } },
        inventory: true,
        variants: {
          where: { isActive: true },
          orderBy: { createdAt: 'asc' },
        },
      },
    });

    if (!product || !product.isActive || product.deletedAt) {
      throw new NotFoundException('Product not found');
    }

    // Store in cache for 5 minutes
    try {
      await this.cacheManager.set(cacheKey, product, 300000);
    } catch (error) {
      console.warn('⚠️  Cache set error:', error.message);
    }

    return product;
  }

  async findBySlug(slug: string, tenantId?: string) {
    const cacheKey = `product:${tenantId || 'global'}:slug:${slug}`;
    
    // Try to get from cache
    try {
      const cached = await this.cacheManager.get(cacheKey);
      if (cached) {
        console.log('📦 Cache HIT:', cacheKey);
        return cached;
      }
    } catch (error) {
      console.warn('⚠️  Cache get error:', error.message);
    }

    console.log('💾 Cache MISS:', cacheKey);

    const product = await this.prisma.product.findFirst({
      where: { slug, ...(tenantId && { tenantId }) },
      include: {
        category: true,
        images: { orderBy: { sortOrder: 'asc' } },
        inventory: true,
        variants: {
          where: { isActive: true },
          orderBy: { createdAt: 'asc' },
        },
      },
    });

    if (!product || !product.isActive || product.deletedAt) {
      throw new NotFoundException('Product not found');
    }

    // Store in cache for 5 minutes
    try {
      await this.cacheManager.set(cacheKey, product, 300000);
    } catch (error) {
      console.warn('⚠️  Cache set error:', error.message);
    }

    return product;
  }

  // Helper method to clear product caches
  private async clearProductCache(productId?: string, slug?: string) {
    try {
      if (productId) {
        await this.cacheManager.del(`product:${productId}`);
      }
      if (slug) {
        await this.cacheManager.del(`product:slug:${slug}`);
      }
      // Note: In production, you'd want to clear all products:* keys
      // This requires Redis SCAN or using a cache store that supports pattern deletion
      console.log('🗑️  Product cache cleared');
    } catch (error) {
      console.warn('⚠️  Cache clear error:', error.message);
    }
  }

  async getFeatured(limit = 8, tenantId?: string) {
    return this.prisma.product.findMany({
      where: {
        isFeatured: true,
        isActive: true,
        deletedAt: null,
        ...(tenantId && { tenantId }),
      },
      include: {
        category: true,
        images: { orderBy: { sortOrder: 'asc' }, take: 1 },
        inventory: true,
        variants: {
          where: { isActive: true },
          orderBy: { createdAt: 'asc' },
        },
      },
      take: limit,
      orderBy: { createdAt: 'desc' },
    });
  }

  async getBestSellers(limit = 8, tenantId?: string) {
    return this.prisma.product.findMany({
      where: {
        isBestSeller: true,
        isActive: true,
        deletedAt: null,
        ...(tenantId && { tenantId }),
      },
      include: {
        category: true,
        images: { orderBy: { sortOrder: 'asc' }, take: 1 },
        inventory: true,
        variants: {
          where: { isActive: true },
          orderBy: { createdAt: 'asc' },
        },
      },
      take: limit,
      orderBy: { createdAt: 'desc' },
    });
  }

  async getCategories(tenantId?: string) {
    return this.prisma.category.findMany({
      where: { isActive: true, ...(tenantId && { tenantId }) },
      include: {
        children: true,
        _count: {
          select: { products: true },
        },
      },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async getQuickCategories(tenantId?: string) {
    // First try to get categories marked as quick categories
    const quickCategories = await this.prisma.category.findMany({
      where: { 
        isActive: true,
        isQuickCategory: true,
        ...(tenantId && { tenantId }),
      },
      include: {
        _count: {
          select: { products: true },
        },
      },
      orderBy: { sortOrder: 'asc' },
    });

    // If we have quick categories, return them
    if (quickCategories.length > 0) {
      return quickCategories;
    }

    // Otherwise, return top 5 categories by product count
    const topCategories = await this.prisma.category.findMany({
      where: { isActive: true, ...(tenantId && { tenantId }) },
      include: {
        _count: {
          select: { products: true },
        },
      },
      orderBy: {
        products: {
          _count: 'desc',
        },
      },
      take: 5,
    });

    return topCategories;
  }
}
